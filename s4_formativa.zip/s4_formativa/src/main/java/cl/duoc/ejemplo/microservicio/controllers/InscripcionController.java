package cl.duoc.ejemplo.microservicio.controllers;

import cl.duoc.ejemplo.microservicio.models.InscripcionRequest;
import cl.duoc.ejemplo.microservicio.services.S3Service;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/inscripciones")
public class InscripcionController {

    private final S3Service s3Service;

    public InscripcionController(S3Service s3Service) {
        this.s3Service = s3Service;
    }

    @PostMapping("/resumen")
    public ResponseEntity<String> generarResumen(@RequestBody InscripcionRequest request) {
        String resumen = construirResumen(request);
        return ResponseEntity.ok(resumen);
    }

    @PostMapping("/{numeroResumen}/upload")
    public ResponseEntity<String> subirResumen(
            @PathVariable String numeroResumen,
            @RequestBody InscripcionRequest request
    ) {
        request.setNumeroResumen(numeroResumen);
        String resumen = construirResumen(request);
        String key = s3Service.subirResumen(numeroResumen, resumen);

        return ResponseEntity.ok("Resumen subido correctamente a S3 en: " + key);
    }

    @PutMapping("/{numeroResumen}")
    public ResponseEntity<String> modificarResumen(
            @PathVariable String numeroResumen,
            @RequestBody InscripcionRequest request
    ) {
        request.setNumeroResumen(numeroResumen);
        String resumen = construirResumen(request);
        String key = s3Service.subirResumen(numeroResumen, resumen);

        return ResponseEntity.ok("Resumen modificado correctamente en S3: " + key);
    }

    @GetMapping("/{numeroResumen}/download")
    public ResponseEntity<String> descargarResumen(@PathVariable String numeroResumen) {
        String contenido = s3Service.descargarResumen(numeroResumen);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=resumen-" + numeroResumen + ".txt")
                .contentType(MediaType.TEXT_PLAIN)
                .body(contenido);
    }

    @DeleteMapping("/{numeroResumen}")
    public ResponseEntity<String> eliminarResumen(@PathVariable String numeroResumen) {
        s3Service.eliminarResumen(numeroResumen);
        return ResponseEntity.ok("Resumen eliminado correctamente: " + numeroResumen);
    }

    private String construirResumen(InscripcionRequest request) {
        return """
                RESUMEN DE INSCRIPCION
                
                Numero de resumen: %s
                Nombre alumno: %s
                Curso: %s
                Correo: %s
                Observacion: %s
                """.formatted(
                request.getNumeroResumen(),
                request.getNombreAlumno(),
                request.getCurso(),
                request.getCorreo(),
                request.getObservacion()
        );
    }
}