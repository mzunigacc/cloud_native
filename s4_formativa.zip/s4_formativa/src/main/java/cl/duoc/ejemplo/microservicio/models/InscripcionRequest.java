package cl.duoc.ejemplo.microservicio.models;

public class InscripcionRequest {
    private String numeroResumen;
    private String nombreAlumno;
    private String curso;
    private String correo;
    private String observacion;

    public String getNumeroResumen() {
        return numeroResumen;
    }

    public void setNumeroResumen(String numeroResumen) {
        this.numeroResumen = numeroResumen;
    }

    public String getNombreAlumno() {
        return nombreAlumno;
    }

    public void setNombreAlumno(String nombreAlumno) {
        this.nombreAlumno = nombreAlumno;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }
}